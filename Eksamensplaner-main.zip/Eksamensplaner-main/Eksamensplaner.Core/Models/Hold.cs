namespace Eksamensplaner.Core.Models;

public class Hold
{
    public int HoldId { get; set; }
    public string HoldName { get; set; }
    public int Semester { get; set; }
}